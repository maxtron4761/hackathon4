import React from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Navbar from './components/Navbar'
import DemoBanner from './components/DemoBanner'
import BackendStatus from './components/BackendStatus'
import ErrorBoundary from './components/ErrorBoundary'
import HomePage from './pages/HomePage'
import AnalyzingPage from './pages/AnalyzingPage'
import ResultsPage from './pages/ResultsPage'

export default function App() {
  return (
    <BrowserRouter>
      <ErrorBoundary>
        <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
          <Navbar />
          <DemoBanner />
          <BackendStatus />
          <main style={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
            <Routes>
              <Route path="/"          element={<HomePage />} />
              <Route path="/analyzing" element={<AnalyzingPage />} />
              <Route path="/results"   element={<ResultsPage />} />
              <Route path="*"          element={<HomePage />} />
            </Routes>
          </main>
          <footer style={{
            borderTop: '1px solid rgba(255,255,255,0.05)',
            padding: '16px 24px',
            display: 'flex',
            justifyContent: 'space-between',
            alignItems: 'center',
            flexWrap: 'wrap',
            gap: 8,
          }}>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)', letterSpacing: '0.08em' }}>
              TRUTHGUARD · AI-Powered Verification System
            </span>
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--text-muted)' }}>
              Powered by Hive AI + Claude · Results are probabilistic
            </span>
          </footer>
        </div>
      </ErrorBoundary>
    </BrowserRouter>
  )
}
