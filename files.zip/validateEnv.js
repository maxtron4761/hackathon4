// ============================================================
//  utils/validateEnv.js — Startup environment validator
// ============================================================
function validateEnv() {
  const issues = []
  const warnings = []

  if (!process.env.ANTHROPIC_API_KEY) {
    issues.push('ANTHROPIC_API_KEY is missing — Claude AI will not work.')
  } else if (!process.env.ANTHROPIC_API_KEY.startsWith('sk-ant-')) {
    issues.push('ANTHROPIC_API_KEY looks wrong (should start with "sk-ant-"). Check your .env file.')
  }

  if (!process.env.HIVE_API_KEY) {
    warnings.push('HIVE_API_KEY not set — deepfake detection will use Claude Vision fallback (less accurate but still works).')
  }

  if (warnings.length > 0) {
    console.log('\n⚠️  Warnings:')
    warnings.forEach(w => console.log(`   • ${w}`))
  }
  if (issues.length > 0) {
    console.error('\n❌  Config Errors (these features will fail):')
    issues.forEach(i => console.error(`   • ${i}`))
    console.error('\n   Fix: open truthguard-backend/.env and add your API keys.\n')
  }
  if (issues.length === 0 && warnings.length === 0) {
    console.log('✅  All environment variables OK.')
  }
}
module.exports = { validateEnv }
