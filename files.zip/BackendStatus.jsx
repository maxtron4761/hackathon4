// ============================================================
//  components/BackendStatus.jsx
//  Checks if backend is reachable on app load & warns user
// ============================================================
import React, { useEffect, useState } from 'react'
import { getHealth, IS_DEMO } from '../utils/api'

export default function BackendStatus() {
  const [status, setStatus] = useState('checking') // 'checking' | 'ok' | 'offline'
  const [services, setServices] = useState(null)
  const [dismissed, setDismissed] = useState(false)

  useEffect(() => {
    if (IS_DEMO) { setStatus('demo'); return }
    getHealth().then(data => {
      if (data?.status === 'ok') {
        setStatus('ok')
        setServices(data.services)
        // Auto-hide success banner after 4s
        setTimeout(() => setDismissed(true), 4000)
      } else {
        setStatus('offline')
      }
    }).catch(() => setStatus('offline'))
  }, [])

  if (dismissed || status === 'checking' || status === 'demo') return null

  if (status === 'offline') {
    return (
      <div style={{
        background: 'rgba(255,68,68,0.08)', borderBottom: '1px solid rgba(255,68,68,0.25)',
        padding: '10px 24px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', gap: 12, flexWrap: 'wrap',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <span style={{ display: 'block', width: 8, height: 8, borderRadius: '50%', background: 'var(--red)', flexShrink: 0 }} />
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--red)', fontWeight: 600 }}>
            Backend Offline
          </span>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', color: 'var(--text-secondary)' }}>
            — Cannot reach server on port 3001. Open a terminal, go to <code style={{ color: 'var(--amber)' }}>truthguard-backend</code> and run <code style={{ color: 'var(--amber)' }}>npm run dev</code>
          </span>
        </div>
        <button onClick={() => setDismissed(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '1rem' }}>✕</button>
      </div>
    )
  }

  if (status === 'ok') {
    return (
      <div style={{
        background: 'rgba(0,230,118,0.06)', borderBottom: '1px solid rgba(0,230,118,0.2)',
        padding: '8px 24px', display: 'flex', alignItems: 'center',
        justifyContent: 'space-between', gap: 12, flexWrap: 'wrap',
        animation: 'fadeIn 0.3s ease both',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 16, flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <span style={{ display: 'block', width: 7, height: 7, borderRadius: '50%', background: 'var(--green)', boxShadow: '0 0 6px var(--green)' }} />
            <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: 'var(--green)', fontWeight: 600 }}>Backend Connected</span>
          </div>
          {services && (
            <div style={{ display: 'flex', gap: 12 }}>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: services.anthropic ? 'var(--green)' : 'var(--red)' }}>
                {services.anthropic ? '✓' : '✗'} Claude
              </span>
              <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.68rem', color: services.hive ? 'var(--green)' : 'var(--amber)' }}>
                {services.hive ? '✓' : '⚠'} Hive AI {!services.hive && '(using Claude Vision fallback)'}
              </span>
            </div>
          )}
        </div>
        <button onClick={() => setDismissed(true)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--text-muted)', fontSize: '0.9rem' }}>✕</button>
      </div>
    )
  }

  return null
}
