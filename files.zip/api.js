// ============================================================
//  utils/api.js — All backend API calls + Demo Mode
// ============================================================
import axios from 'axios'
import {
  DEMO_FAKENEWS_RESULT,
  DEMO_DEEPFAKE_RESULT,
  DEMO_MOSTLY_TRUE_RESULT,
} from './demoData'

const BASE_URL = '/api'
const api = axios.create({ baseURL: BASE_URL, timeout: 120000 })

// ─── Demo mode detection ─────────────────────────────────────
// Demo mode activates when:
//   1. You set VITE_DEMO_MODE=true in .env.local, OR
//   2. The backend is unreachable (auto-fallback)
export const IS_DEMO = import.meta.env.VITE_DEMO_MODE === 'true'

// Fake delay so demo feels realistic
const fakeDelay = (ms) => new Promise((r) => setTimeout(r, ms))

// ─── Deepfake analysis ───────────────────────────────────────
export async function analyzeDeepfake(file, onProgress) {
  if (IS_DEMO) {
    // Simulate upload progress
    for (let p = 0; p <= 100; p += 20) {
      await fakeDelay(150)
      onProgress?.(p)
    }
    await fakeDelay(2800) // Simulate processing time
    return DEMO_DEEPFAKE_RESULT
  }
  const formData = new FormData()
  formData.append('image', file)
  const res = await api.post('/deepfake/analyze', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => {
      if (onProgress && e.total) onProgress(Math.round((e.loaded / e.total) * 100))
    },
  })
  return res.data
}

export async function analyzeDeepfakeUrl(imageUrl) {
  if (IS_DEMO) {
    await fakeDelay(3200)
    return DEMO_DEEPFAKE_RESULT
  }
  const res = await api.post('/deepfake/analyze-url', { imageUrl })
  return res.data
}

// ─── Fake news analysis ──────────────────────────────────────
export async function analyzeFakeNews(text, inputType = 'text') {
  if (IS_DEMO) {
    await fakeDelay(5500) // Simulate multi-search delay
    // Vary the demo result based on text length for variety
    return text.length % 2 === 0 ? DEMO_FAKENEWS_RESULT : DEMO_MOSTLY_TRUE_RESULT
  }
  const res = await api.post('/fakenews/analyze', { text, inputType })
  return res.data
}

// ─── Health check ─────────────────────────────────────────────
export async function getHealth() {
  if (IS_DEMO) {
    return { status: 'demo', services: { anthropic: false, hive: false, deepfake_fallback: 'demo' } }
  }
  try {
    const res = await api.get('/health', { timeout: 4000 })
    return res.data
  } catch {
    return null // Backend offline
  }
}

// ─── Error parser ─────────────────────────────────────────────
export function parseApiError(err) {
  if (err.response) {
    const { status, data } = err.response
    if (status === 429) return 'Too many requests. Please wait a moment and try again.'
    if (status === 413) return 'File is too large. Maximum size is 10MB.'
    if (status === 422) return data?.error || 'Could not process this image. Is it a valid JPEG/PNG/WebP?'
    if (data?.error) return data.error
    if (data?.details) return data.details.join('. ')
    return `Server error (${status}). Please try again.`
  }
  if (err.code === 'ECONNABORTED') return 'Request timed out — analysis is taking too long. Please try again.'
  if (!err.response) return 'Cannot reach backend. Is the server running on port 3001?'
  return err.message || 'An unexpected error occurred.'
}
