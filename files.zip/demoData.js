// ============================================================
//  utils/demoData.js — Realistic mock results for Demo Mode
//  Used when VITE_DEMO_MODE=true or backend is unreachable
// ============================================================

export const DEMO_FAKENEWS_RESULT = {
  requestId: 'demo-fakenews-001',
  type: 'fakenews_analysis',
  timestamp: new Date().toISOString(),
  processingTimeMs: 8342,
  input: { type: 'text', length: 89, fetchedUrl: null },
  analysis: {
    verdict: 'FALSE',
    trustScore: 12,
    summary:
      'This claim is false and has been debunked by NASA astronauts who have been in orbit. ' +
      'The Great Wall of China is only about 9 metres wide — far too narrow to be seen from ' +
      'space with the naked eye. Multiple authoritative sources confirm this is a long-standing myth.',
    claims: [
      {
        claim: 'The Great Wall of China is visible from space with the naked eye',
        verdict: 'FALSE',
        explanation:
          'At roughly 9 metres wide, the wall is narrower than a human hair when viewed from low Earth orbit. ' +
          'NASA astronaut Ed Lu confirmed it is not visible without optical aids.',
        sources: [
          'https://www.nasa.gov/vision/space/workinginspace/great_wall.html',
          'https://www.snopes.com/fact-check/great-wall-of-china-visible-from-space/',
        ],
      },
      {
        claim: 'It can be seen from the Moon',
        verdict: 'FALSE',
        explanation:
          'From the Moon (384,000 km away), even entire continents barely appear as shapes. ' +
          'No man-made structure is visible from the Moon.',
        sources: ['https://www.nationalgeographic.com/science/article/great-wall-china-visible-space'],
      },
    ],
    sources: [
      {
        url: 'https://www.nasa.gov/vision/space/workinginspace/great_wall.html',
        title: 'NASA — Great Wall Visibility from Space',
        credibilityTier: 1,
        relevance: 'NASA directly addresses this myth, citing astronaut observations and physics calculations.',
        supports: 'DEBUNKS',
        publisher: 'nasa.gov',
      },
      {
        url: 'https://www.snopes.com/fact-check/great-wall-of-china-visible-from-space/',
        title: 'Snopes Fact Check — Great Wall of China',
        credibilityTier: 3,
        relevance: 'Snopes rates this claim as FALSE, with extensive historical research.',
        supports: 'DEBUNKS',
        publisher: 'snopes.com',
      },
      {
        url: 'https://www.nationalgeographic.com/science/article/great-wall-china-visible-space',
        title: 'National Geographic — The Great Wall Myth',
        credibilityTier: 2,
        relevance: 'National Geographic provides scientific context on human visual limits in orbit.',
        supports: 'DEBUNKS',
        publisher: 'nationalgeographic.com',
      },
      {
        url: 'https://www.scientificamerican.com/article/is-chinas-great-wall-visible/',
        title: 'Scientific American — Wall Visibility Analysis',
        credibilityTier: 1,
        relevance: 'Peer-reviewed analysis of angular resolution and what is physically detectable from orbit.',
        supports: 'CONTEXTUALIZES',
        publisher: 'scientificamerican.com',
      },
    ],
    context:
      'This myth has been circulating since the 1930s, appearing in textbooks and popular culture. ' +
      'It was officially tested and disproven when astronauts reached orbit. The confusion may ' +
      'stem from the wall\'s enormous LENGTH (21,000 km), not its width.',
    redFlags: [
      'Claim has been circulating as myth since the 1930s',
      'Contradicts basic physics of human visual resolution at altitude',
      'No primary source (astronaut or photo) has ever confirmed it',
    ],
    positiveIndicators: [],
    inputAnalysis: {
      inputType: 'TEXT',
      topic: 'Geography / Space / Popular Myths',
      dateRelevance: 'This is a timeless factual claim — date does not affect the verdict.',
      originalSource: 'Unknown — widely repeated urban myth',
    },
    searchesPerformed: 5,
  },
}

export const DEMO_DEEPFAKE_RESULT = {
  requestId: 'demo-deepfake-001',
  type: 'deepfake_analysis',
  timestamp: new Date().toISOString(),
  processingTimeMs: 4218,
  image: {
    originalFilename: 'sample_image.jpg',
    originalMimeType: 'image/jpeg',
    width: 1024,
    height: 768,
    originalSizeKb: 342,
    processedSizeKb: 289,
  },
  analysis: {
    provider: 'hive_ai',
    verdict: 'LIKELY_MANIPULATED',
    deepfakeScore: 74,
    authenticityScore: 26,
    confidence: 81,
    summary:
      'The image shows several strong indicators of AI manipulation or deepfake generation. ' +
      'Facial boundary blending, unnatural skin texture patterns, and lighting direction ' +
      'inconsistencies suggest this image has been digitally altered.',
    indicators: [
      {
        category: 'Facial Boundaries',
        finding: 'Subtle but detectable blending artefacts along the hairline and jaw edge, consistent with face-swap technology.',
        severity: 'HIGH',
        suggestsManipulation: true,
      },
      {
        category: 'Skin Texture',
        finding: 'Overly smooth skin texture with a characteristic GAN "painting" quality, lacking natural pore detail.',
        severity: 'HIGH',
        suggestsManipulation: true,
      },
      {
        category: 'Eye Reflections',
        finding: 'Left and right eye catchlights are inconsistent — different light source angles detected.',
        severity: 'MEDIUM',
        suggestsManipulation: true,
      },
      {
        category: 'Lighting & Shadows',
        finding: 'Background lighting direction does not match the light falling on the subject\'s face.',
        severity: 'MEDIUM',
        suggestsManipulation: true,
      },
      {
        category: 'Background Coherence',
        finding: 'Background appears natural with no detectable anomalies.',
        severity: 'NONE',
        suggestsManipulation: false,
      },
      {
        category: 'Compression Artifacts',
        finding: 'JPEG blocking patterns are inconsistent between the face region and background, suggesting compositing.',
        severity: 'LOW',
        suggestsManipulation: true,
      },
    ],
    allClasses: [
      { label: 'deepfake', score: 74 },
      { label: 'real', score: 26 },
      { label: 'ai_generated', score: 68 },
      { label: 'face_swap', score: 61 },
    ],
    technicalNotes:
      'GAN fingerprinting analysis detected spectral anomalies in the 64–128Hz frequency band, ' +
      'which is a known signature of StyleGAN2 and similar architectures. ' +
      'Noise pattern analysis shows non-uniform distribution inconsistent with natural camera sensor noise.',
    limitations:
      'Analysis confidence is limited by image resolution (1024×768). ' +
      'A higher-resolution source would allow more precise artifact detection. ' +
      'Results should be treated as probabilistic, not definitive.',
  },
  meta: {
    usedFallback: false,
    fallbackReason: null,
    primaryProvider: 'hive_ai',
    actualProvider: 'hive_ai',
  },
}

export const DEMO_MOSTLY_TRUE_RESULT = {
  requestId: 'demo-fakenews-002',
  type: 'fakenews_analysis',
  timestamp: new Date().toISOString(),
  processingTimeMs: 6120,
  input: { type: 'text', length: 74, fetchedUrl: null },
  analysis: {
    verdict: 'MOSTLY_TRUE',
    trustScore: 78,
    summary:
      'This claim is mostly accurate. Lightning does strike the same place twice — in fact, ' +
      'tall structures like the Empire State Building are struck hundreds of times per year. ' +
      'The popular saying is a myth in the literal sense.',
    claims: [
      {
        claim: 'Lightning never strikes the same place twice',
        verdict: 'FALSE',
        explanation: 'Lightning absolutely does strike the same place repeatedly. The Empire State Building is struck about 20–25 times per year.',
        sources: ['https://www.noaa.gov/lightning-safety', 'https://www.scientificamerican.com/article/lightning-same-place/'],
      },
    ],
    sources: [
      {
        url: 'https://www.noaa.gov/lightning-safety',
        title: 'NOAA — Lightning Safety Facts',
        credibilityTier: 1,
        relevance: 'NOAA directly states lightning strikes the same location repeatedly, citing meteorological data.',
        supports: 'DEBUNKS',
        publisher: 'noaa.gov',
      },
      {
        url: 'https://www.scientificamerican.com/article/lightning-same-place/',
        title: 'Scientific American — Lightning Strike Patterns',
        credibilityTier: 1,
        relevance: 'Peer-reviewed explanation of lightning path physics and why tall objects attract repeated strikes.',
        supports: 'CONTEXTUALIZES',
        publisher: 'scientificamerican.com',
      },
    ],
    context: 'The saying "lightning never strikes twice" is a common idiom meaning unlikely events don\'t repeat. Physically, it is completely false.',
    redFlags: ['Well-known folk saying, not a scientific fact'],
    positiveIndicators: ['Core scientific principle is well-established and easily verifiable'],
    inputAnalysis: {
      inputType: 'TEXT',
      topic: 'Meteorology / Popular Myths',
      dateRelevance: 'Timeless factual claim.',
      originalSource: 'Common folk saying',
    },
    searchesPerformed: 3,
  },
}
