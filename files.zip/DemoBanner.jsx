// ============================================================
//  components/DemoBanner.jsx — Shown when demo mode is active
// ============================================================
import React, { useState } from 'react'
import { IS_DEMO } from '../utils/api'

export default function DemoBanner() {
  const [dismissed, setDismissed] = useState(false)
  if (!IS_DEMO || dismissed) return null

  return (
    <div style={{
      background: 'linear-gradient(90deg, rgba(255,170,0,0.12), rgba(255,170,0,0.06))',
      borderBottom: '1px solid rgba(255,170,0,0.3)',
      padding: '10px 24px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: 12,
      flexWrap: 'wrap',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <span style={{ fontSize: '1rem' }}>🎭</span>
        <div>
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
            fontWeight: 700, color: 'var(--amber)', letterSpacing: '0.08em',
            textTransform: 'uppercase',
          }}>
            Demo Mode Active
          </span>
          <span style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
            color: 'var(--text-secondary)', marginLeft: 10,
          }}>
            Results are simulated — no API keys or backend needed. Safe to explore everything for free.
          </span>
        </div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
        <span style={{
          fontFamily: 'var(--font-mono)', fontSize: '0.7rem',
          color: 'var(--text-muted)',
        }}>
          To use real AI: remove <code style={{ color: 'var(--amber)', background: 'rgba(255,170,0,0.1)', padding: '1px 5px', borderRadius: 3 }}>VITE_DEMO_MODE=true</code> from <code style={{ color: 'var(--amber)', background: 'rgba(255,170,0,0.1)', padding: '1px 5px', borderRadius: 3 }}>.env.local</code>
        </span>
        <button onClick={() => setDismissed(true)} style={{
          background: 'none', border: 'none', cursor: 'pointer',
          color: 'var(--text-muted)', fontSize: '1rem', padding: '2px 6px',
          lineHeight: 1, borderRadius: 4, transition: 'color 0.15s',
        }}
          onMouseEnter={e => e.currentTarget.style.color = 'var(--text-primary)'}
          onMouseLeave={e => e.currentTarget.style.color = 'var(--text-muted)'}
        >
          ✕
        </button>
      </div>
    </div>
  )
}
