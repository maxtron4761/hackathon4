# TruthGuard — Complete Setup Guide
## Everything you need to go from zero to running app

---

## What is this app?

TruthGuard has two features:
- **Deepfake Detection** — Upload an image or screenshot. The app uses Hive AI (a real ML model) to tell you if it has been AI-generated or manipulated.
- **Fake News Detection** — Paste any text claim or a website URL. The app searches the internet in real time, cross-references multiple sources, and gives you a trust score (0–100) with every source it used.

---

## Part 1 — Folder Setup

Create this structure on your computer (Desktop is a good location):

```
📁 truthguard/
    ├── 📁 truthguard-backend/    ← files from Prompt 1
    └── 📁 truthguard-frontend/   ← files from Prompt 2 + 3
```

**Rule for placing files:** The file path shown in Claude tells you exactly where it goes.
- Path starts with `truthguard-backend/` → goes in the backend folder
- Path starts with `truthguard-frontend/` → goes in the frontend folder
- A path like `routes/deepfake.js` means create a `routes` folder and put `deepfake.js` inside it

---

## Part 2 — Install Node.js (one time only)

Node.js is the engine that runs JavaScript on your computer.

1. Go to **https://nodejs.org**
2. Click the big green **LTS** button
3. Download and install like any normal program
4. Done — you never open it directly

**To verify it worked:** Open a terminal and type `node --version`
You should see something like `v20.x.x`

---

## Part 3 — Choose Your Mode

### 🎭 Option A: Demo Mode (FREE — no API keys, no backend needed)
Perfect for exploring the full app before spending anything.

1. Go into your `truthguard-frontend` folder
2. Create a new file called `.env.local` (exactly that name, with the dot)
3. Open it in any text editor and add this one line:
   ```
   VITE_DEMO_MODE=true
   ```
4. Save it

That's it. In demo mode, the frontend works completely alone.
You will see a yellow banner at the top saying "Demo Mode Active."
All results are realistic simulations — not real AI.

**To switch to real mode later:** delete that line (or change `true` to `false`).

---

### 🔑 Option B: Real Mode (requires API keys)

#### Step 1 — Get your Anthropic API key (required)
- Go to **https://console.anthropic.com**
- Sign up and log in
- Click **API Keys** → **Create Key**
- Copy the key — it starts with `sk-ant-api...`
- Minimum top-up: $5 (enough for ~100–200 analyses)

#### Step 2 — Get your Hive AI key (optional, free tier available)
- Go to **https://hivemoderation.com**
- Sign up for a free account
- Find your API key in the dashboard
- Free tier: 100 image analyses per month
- **If you skip this:** the app still works — it uses Claude Vision as a backup for deepfake detection (slightly less accurate)

#### Step 3 — Create your backend .env file
1. Go into your `truthguard-backend` folder
2. Find the file called `.env.example`
3. **Copy** it and rename the copy to `.env` (remove `.example`)
4. Open `.env` in any text editor. It looks like this:
   ```
   ANTHROPIC_API_KEY=your_anthropic_api_key_here
   HIVE_API_KEY=your_hive_api_key_here
   PORT=3001
   ```
5. Replace `your_anthropic_api_key_here` with your real key
6. Replace `your_hive_api_key_here` with your real Hive key (or delete that line if you don't have one)
7. Save the file

⚠️ **Never share the .env file. It contains your passwords.**

---

## Part 4 — Running the App

### In Demo Mode (no backend needed)
You only need ONE terminal window.

```bash
# Navigate to the frontend folder
cd Desktop/truthguard/truthguard-frontend

# Install libraries (first time only — takes 1-2 minutes)
npm install

# Start the app
npm run dev
```

Open your browser and go to: **http://localhost:3000**

---

### In Real Mode (needs both terminals running)

**Terminal 1 — Start the backend:**
```bash
cd Desktop/truthguard/truthguard-backend
npm install
npm run dev
```
You should see: `✅ TruthGuard API running on http://localhost:3001`

**Terminal 2 — Start the frontend:**
```bash
cd Desktop/truthguard/truthguard-frontend
npm install
npm run dev
```
You should see: `➜ Local: http://localhost:3000/`

Open your browser and go to: **http://localhost:3000**

---

## Part 5 — Testing It Works

### Quick test 1 — Check the backend is alive (Real Mode only)
Open your browser and go to: `http://localhost:3001/api/health`

You should see:
```json
{ "status": "ok", "services": { "anthropic": true, "hive": true } }
```
If `"anthropic"` shows `false`, your Anthropic key is wrong or missing.

### Quick test 2 — Fake news check
1. Go to `http://localhost:3000`
2. Click the **News / Claim** tab
3. Paste: *"The Great Wall of China is visible from space with the naked eye"*
4. Click **Fact-Check**
5. Wait 20–40 seconds (it's doing real web searches)
6. You'll see a FALSE verdict with real source links

### Quick test 3 — Deepfake check
1. Save any photo from Google Images to your computer
2. Go to `http://localhost:3000`
3. Drag and drop your photo into the upload box
4. Click **Analyze Image**
5. Wait 5–15 seconds
6. You'll see the forensic breakdown

---

## Part 6 — Understanding the Results Screen

### For Fake News:
| Element | What it means |
|---|---|
| **Trust Score (0–100)** | 100 = completely trustworthy. 0 = completely false. |
| **Verdict badge** | TRUE / MOSTLY TRUE / MISLEADING / FALSE / UNVERIFIABLE |
| **Claims breakdown** | Each individual claim extracted and checked separately |
| **Sources — T1 to T5** | T1 = most credible (NASA, WHO, BBC). T5 = least credible (unknown blogs) |
| **Supports / Debunks / Context** | Whether each source agrees, disagrees, or adds context |
| **Searches Performed** | How many web searches Claude ran to fact-check |

### For Deepfake:
| Element | What it means |
|---|---|
| **Deepfake Score %** | How likely the image is manipulated |
| **Authenticity Score %** | How likely the image is genuine |
| **Confidence %** | How sure the system is about its verdict |
| **Forensic Indicators** | Specific things found: skin texture, eye reflections, lighting, etc. |
| **Provider** | "Hive AI" (ML model) or "Claude Vision" (AI fallback) |

---

## Part 7 — Stopping the App

To stop: go to each terminal window and press `Ctrl + C`

---

## Part 8 — Common Problems

| Problem | Solution |
|---|---|
| `npm is not recognized` | Node.js is not installed. Go to nodejs.org |
| Blank white screen | Open browser console (F12) and look for red errors |
| `Cannot reach backend` | Backend terminal is closed. Run `npm run dev` in backend folder |
| `Invalid API key` | Your `.env` file has wrong key or extra spaces around the `=` sign |
| Results never load | Text might be too long (max 5000 chars) or image too big (max 10MB) |
| `CORS error` in console | Backend isn't running, or is on a different port |
| Yellow "Demo Mode" banner | You have `VITE_DEMO_MODE=true` in your `.env.local` — remove it for real mode |

---

## Part 9 — File Map (What Every File Does)

### Backend (`truthguard-backend/`)
| File | What it does |
|---|---|
| `server.js` | The main engine. Starts the server, sets up security |
| `routes/deepfake.js` | Handles incoming image uploads |
| `routes/fakenews.js` | Handles incoming text/URL submissions |
| `services/hiveService.js` | Sends images to Hive AI and reads the result |
| `services/claudeVisionService.js` | Backup deepfake analysis using Claude |
| `services/fakeNewsService.js` | Runs web searches + fact-checks using Claude |
| `middleware/errorHandler.js` | Catches any errors so app doesn't crash |
| `utils/validateEnv.js` | Checks your API keys on startup |
| `.env` | Your secret API keys (you create this) |
| `.env.example` | Template showing what the .env file should look like |

### Frontend (`truthguard-frontend/`)
| File | What it does |
|---|---|
| `src/App.jsx` | The router — decides which page to show |
| `src/pages/HomePage.jsx` | The main screen with upload and text input |
| `src/pages/AnalyzingPage.jsx` | The loading screen with progress steps |
| `src/pages/ResultsPage.jsx` | The full results dashboard |
| `src/components/TrustMeter.jsx` | The animated circular trust gauge |
| `src/components/VerdictBadge.jsx` | The coloured verdict label (TRUE/FALSE/etc.) |
| `src/components/SourceCard.jsx` | Each individual source citation card |
| `src/components/ClaimCard.jsx` | Each individual claim breakdown card |
| `src/components/DeepfakeResult.jsx` | The deepfake score bars and indicators |
| `src/components/DemoBanner.jsx` | Yellow banner shown in demo mode |
| `src/components/BackendStatus.jsx` | Green/red banner showing backend connection |
| `src/components/ErrorBoundary.jsx` | Catches app crashes and shows a helpful screen |
| `src/utils/api.js` | All the calls to the backend |
| `src/utils/constants.js` | Colours and labels for each verdict type |
| `src/utils/demoData.js` | Realistic fake results used in demo mode |
| `src/index.css` | All the visual styles (colours, fonts, layout) |
| `.env.local` | Your frontend settings (you create this) |

---

## Cost Reference

| Action | Approx. Cost (Anthropic) |
|---|---|
| One fake news check (short text) | ~$0.02 |
| One fake news check (long article) | ~$0.05–0.10 |
| One deepfake check (Claude Vision fallback) | ~$0.01–0.03 |
| One deepfake check (Hive AI) | Free up to 100/month |
| $5 Anthropic credit | ~50–200 analyses |

