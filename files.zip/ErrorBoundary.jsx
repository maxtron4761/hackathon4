// ============================================================
//  components/ErrorBoundary.jsx
//  Catches any React crash and shows a helpful message
//  instead of a blank white screen
// ============================================================
import React from 'react'

export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props)
    this.state = { hasError: false, error: null }
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error }
  }

  componentDidCatch(error, info) {
    console.error('TruthGuard caught a crash:', error, info)
  }

  render() {
    if (!this.state.hasError) return this.props.children

    return (
      <div style={{
        minHeight: '100vh', display: 'flex', alignItems: 'center',
        justifyContent: 'center', padding: 24, flexDirection: 'column',
        background: 'var(--bg-void)',
      }}>
        <div style={{
          maxWidth: 520, width: '100%',
          background: 'var(--bg-card)', border: '1px solid rgba(255,68,68,0.3)',
          borderRadius: 'var(--radius-xl)', padding: '40px 36px', textAlign: 'center',
        }}>
          <div style={{ fontSize: '3rem', marginBottom: 16 }}>⚠️</div>
          <h2 style={{
            fontFamily: 'var(--font-display)', fontSize: '1.3rem',
            fontWeight: 700, color: 'var(--text-primary)', marginBottom: 12,
          }}>
            Something went wrong
          </h2>
          <p style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.82rem',
            color: 'var(--text-secondary)', lineHeight: 1.7, marginBottom: 24,
          }}>
            The app hit an unexpected error. This is usually caused by a missing
            backend connection or an invalid API response.
          </p>

          {/* Error detail (collapsed) */}
          <details style={{ textAlign: 'left', marginBottom: 24 }}>
            <summary style={{
              fontFamily: 'var(--font-mono)', fontSize: '0.75rem',
              color: 'var(--text-muted)', cursor: 'pointer', marginBottom: 8,
            }}>
              Show technical details
            </summary>
            <pre style={{
              background: 'var(--bg-deep)', borderRadius: 6,
              padding: '12px', fontSize: '0.7rem', color: 'var(--red)',
              overflow: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word',
              border: '1px solid var(--border-dim)', marginTop: 8,
            }}>
              {this.state.error?.message || 'Unknown error'}
            </pre>
          </details>

          {/* Actions */}
          <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
            <button
              className="btn btn-primary"
              onClick={() => { this.setState({ hasError: false, error: null }); window.location.href = '/' }}
            >
              ↩ Go Home
            </button>
            <button
              className="btn btn-ghost"
              onClick={() => window.location.reload()}
            >
              ↻ Reload Page
            </button>
          </div>

          <p style={{
            fontFamily: 'var(--font-mono)', fontSize: '0.68rem',
            color: 'var(--text-muted)', marginTop: 20, lineHeight: 1.6,
          }}>
            If this keeps happening, make sure your backend is running on port 3001
            and your <code style={{ color: 'var(--amber)' }}>.env</code> file has valid API keys.
          </p>
        </div>
      </div>
    )
  }
}
